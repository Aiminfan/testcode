import pythonaddins
import arcpy
import webbrowser
import functools
import threading
import time

class Information(object):
    """Implementation for Streetview_addin.tool2 (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "NONE"
    def onClick(self):
        current_date = str(time.strftime("%b %d, %Y"))
        pythonaddins.MessageBox("Last Updated:\nFeb 04, 2015\n\nCurrent Date:\n{0}\n\n------------------------\nStreet View\n1.0v2\n------------------------\n\nFor updates visit:\nwww.ianbroad.com".format(current_date), "Information", 0)

class StreetView(object):
    """Implementation for StreetView_addin.tool1 (Tool)"""
    def __init__(self):
        self.enabled = True
        self.cursor = 3
        self.shape = "NONE"

    def onMouseDownMap(self, x, y, button, shift):

        mxd = arcpy.mapping.MapDocument("CURRENT")
        view = mxd.activeView

        sr = arcpy.mapping.ListDataFrames(mxd)[0].spatialReference
        code = sr.factoryCode

        if view == "PAGE_LAYOUT":
            pythonaddins.MessageBox("This tool will not work in Layout View. Please change to Data View.", "Warning", 0)

        elif code == 0:
            pythonaddins.MessageBox("The current Data Frame coordinate system is not an ESRI standard. \n\nThe coordinate system cannot be custom, or undefined.", "Warning", 0)

        else:

            click = arcpy.Point(x, y)

            sr_new = arcpy.SpatialReference(4326)
            click_geom = arcpy.PointGeometry(click, sr)
            coords = click_geom.projectAs(sr_new)

            x_coord = float(coords.firstPoint.X)
            y_coord = float(coords.firstPoint.Y)

            url = "http://maps.google.com/?cbll={0},{1}&cbp=12,90,0,0,5&layer=c".format(y_coord, x_coord)

            def run_in_other_thread(function):
                @functools.wraps(function)
                def fn_(*args, **kwargs):
                    thread = threading.Thread(target=function, args=args, kwargs=kwargs)
                    thread.start()
                    thread.join()
                return fn_

            openbrowser = run_in_other_thread(webbrowser.open)
            openbrowser(url, new=2)

            del click
            del click_geom
            del coords
            del openbrowser