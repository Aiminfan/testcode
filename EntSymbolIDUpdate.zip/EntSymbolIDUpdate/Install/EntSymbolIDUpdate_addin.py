import logging, os, datetime
import logging.handlers
import arcpy
import pythonaddins

def initLogger(logpath=''):
    #Setup logging - levels are DEBUG,INFO,WARNING,ERROR,CRITICAL
    logging.basicConfig(level=logging.INFO)
    #Logging level specified in script configuration
    logger = logging.getLogger("Test")
    logFileName=os.path.basename(__file__)
    logFileName=logFileName.split('.')[0]
    logFileName = logFileName + datetime.datetime.now().strftime('%Y%m%d%H%M')+'.log'
    logFileName=os.path.join(logpath,logFileName)
    fileHandler = logging.handlers.RotatingFileHandler(logFileName, maxBytes=500000, backupCount=10)
    #formatter = logging.Formatter('%(asctime)s %(levelname)s %(relativeCreated)d \n%(filename)s %(module)s %(funcName)s %(lineno)d \n%(message)s\n')
    formatter = logging.Formatter('%(asctime)s:\n%(message)s\n')
    fileHandler.setFormatter(formatter)
    logger.addHandler(fileHandler)
    logger.info('log initialized: location {}'.format(logFileName))
    return logger

def joinCheck(lyr):
  fList = arcpy.Describe(lyr).fields
  for f in fList:
    if f.name.find(lyr.datasetName) > -1:
      return True
  return False
def getSymbolIDStatus(code):
    if code==3:
        return 'IS'
    elif code==4:
        return 'A'
    elif code==5:
        return 'B'
    elif code==6:
        return 'P'
    elif code==7:
        return 'R'
def getSubtype(fctype,code):
    if fctype=='eFuseBank':
        if code==1:
            return 'O'
        elif code==2:
            return 'U'
    elif fctype=='eServiceLocation':
        if code==1:
            return 'SP'
        elif code==2:
            return 'PME'
        elif code==3:
            return 'BD'
    elif fctype=='Elster_Equip':
        if code==1:
            return 'G'
        elif code==2:
            return 'R'
    elif fctype=='eDynamicProtectiveDeviceBank':
        if code==1:
            return 'CB'
        elif code==2:
            return 'R'
        elif code==3:
            return 'SE'
        elif code==4:
            return 'VB'
    elif fctype=='ePrimaryUGLineSection':
        if code==1:
            return 'SO'
        elif code==2:
            return 'TWO'
        elif code==3:
            return 'THO'
        elif code==4:
            return 'SB'
    elif fctype=='ePrimaryOHLineSection':
        if code==1:
            return 'SU'
        elif code==2:
            return 'TWU'
        elif code==3:
            return 'THU'
        elif code==4:
            return 'SCB'
        elif code==5:
            return 'VB'
    elif fctype=='eSurfaceStructure':
        if code==1:
            return 'SC'
        elif code==2:
            return 'JB'
        elif code==3:
            return 'Ped'
        elif code==4:
            return 'Pad'
        elif code==7:
            return 'UB'
        elif code==8:
            return 'MC'
    elif fctype=='eUndergroundStructure':
        if code==1:
            return 'M'
        elif code==2:
            return 'H'
        elif code==3:
            return 'V'
    elif  fctype=='eSwitchBank':
        if code==1:
            return 'O'
        elif code==2:
            return 'U'
        elif code==3:
            return 'E'
        elif code==4:
            return 'M'
    elif  fctype=='eMiscellaneousNetworkFeature':
        if code==1:
            return 'DE'
        elif code==2:
            return 'J'
        elif code==3:
            return 'N'
        elif code==4:
            return 'S'
        elif code==5:
            return 'FI'
        elif code==6:
            return 'PH'
        elif code==7:
            return 'A'
        elif code==8:
            return 'SR'
        elif code==9:
            return 'U'
        elif code==10:
            return 'CC'

    return ''
def getStatus(NORMALR,NORMALW,NORMALB):
    if NORMALR==1 or NORMALW==1 or NORMALB==1:
        return 'C'
    elif NORMALR==0 or NORMALW==0 or NORMALB==0:
        return 'O'
    else:
        return ''
def getPhasingcode(code):
    if code==1:
       return 'B'
    elif code==2:
        return 'W'
    elif code==3:
        return 'WB'
    elif code==4:
        return 'R'
    elif code==5:
        return 'RB'
    elif code==6:
        return 'RW'
    elif code==7:
        return 'RWB'
    else:
        return ''
def geteOwner(code):
    if not code:
        return ''
    if code=='HYDROONE':
       return 'H'
    elif code=='BELL':
        return 'B'
    elif code=='CABLE':
        return 'C'
    elif code=='PRIVATE':
        return 'P'
    elif code=='ENTEGRUS':
        return 'E'
    elif code=='MOCK':
        return 'MCK'
    elif code=='MOSC':
        return 'MSC'
    elif code=='MONM':
        return 'MNM'
    elif code=='MONB':
        return 'MN'
    elif code=='MOSTT':
        return 'MST'
    elif code=='MODD':
        return 'MD'
    elif code.upper()=='ROGERS':
        return 'R'
    elif code=='TekSavvy':
        return 'T'
    elif code=='ENT_FIBRE':
        return 'EF'
    else:
        return ''
def getOPVoltage(code):
    if code==20:
       return '120'
    elif code==30:
        return '208'
    elif code==40:
        return '240'
#    elif code==50:
#        return '208'
#    elif code==60:
#        return '480'
#    elif code==70:
#        return '347'
    elif code==80:
        return '347'
    elif code==90:
        return '600'
    elif code==120:
        return '24'
    elif code==130:
        return '416'
    elif code==140:
        return '48'
    elif code==150:
        return '83'
#    elif code==160:
#        return '15'
    elif code==170:
        return '16'
#    elif code==180:
#        return '25'
    elif code==190:
        return '276'
#    elif code==200:
#        return '345'
    elif code==210:
        return '24D'
    elif code==220:
        return '138'
    else:
        return ''
def getSymbolIDSubtype(fcname,subtype):
    return getSubtype(fcname,subtype)
def getStyle(code):
    if code=='PADMOUNT':
       return 'Pd'
    elif code=='PLATFORM':
        return 'Plf'
    elif code=='POLEMOUNT':
        return 'Plm'
    elif code=='POLETRANS':
        return 'Ptr'
    elif code=='STEPDOWN':
        return 'Stp'
    elif code=='SUBMERSIBLE':
        return 'Sb'
    else:
        return ''
def getCritical(code):
    if code=='A':
       return 'Life'
    elif code=='B':
        return 'Pub'
    elif code=='C':
        return 'Pol'
    elif code=='D':
        return 'Com'
    elif code=='E':
        return 'TL'
    elif code=='F':
        return 'R'
    elif code=='G':
        return 'NS'
    else:
        return 'NO'

def getTXSymbolID(feederid,owner,OPVoltage,phasingcode,style):
    if feederid:
        VReturn=feederid
    else:
        VReturn=''
    o=geteOwner(owner)
    if o:
        VReturn=VReturn+'.'+o
    op=getOPVoltage(OPVoltage)
    if op:
        VReturn=VReturn+op
    p=getPhasingcode(phasingcode)
    if p:
        VReturn=VReturn+p
    s=getStyle(style)
    if s:
        VReturn=VReturn+'.'+s
    return VReturn
def getFuseSwitchSymbolID(fctype,feederid,owner,OPVoltage,phasingcode,subtype,NORMALR,NORMALW,NORMALB):
    # fctype 'Fuse' for eFuseBank
    if feederid:
        VReturn=feederid
    else:
        VReturn=''
    o=geteOwner(owner)
    if o:
        VReturn=VReturn+'.'+o
    op=getOPVoltage(OPVoltage)
    if op:
        VReturn=VReturn+op
    p=getPhasingcode(phasingcode)
    if p:
        VReturn=VReturn+p
    s=getSubtype(fctype,subtype)
    if s:
        VReturn=VReturn+'.'+s
    oc=getStatus(NORMALR,NORMALW,NORMALB)
    if oc:
        VReturn=VReturn+'.'+oc
    if len(VReturn)>20:
        print('{} is too long!'.format(VReturn))
        VReturn=VReturn[:20]
    return VReturn
def getNodeSymbolID(fctype,subtype,phasingcode,feederid,OPVoltage):
    VReturn= getSubtype(fctype,subtype)
    p=getPhasingcode(phasingcode)
    if p:
        if VReturn:
            VReturn=VReturn+'.'+p
        else:
             VReturn='.'+p
    if feederid:
        VReturn=VReturn+'.'+feederid
    op=getOPVoltage(OPVoltage)
    if op:
        VReturn=VReturn+'.'+op
    return VReturn
def getServiceSymbolID(fctype,subtype,critical):
    VReturn= getSubtype(fctype,subtype)
    c=getCritical(critical)
    if c:
        VReturn=VReturn+'.'+c
    return VReturn
def getPrimarySymbolID(fctype,feederid,owner,phasingcode,OPVoltage,subtype):
    if feederid:
        VReturn=feederid
    else:
        VReturn=''
    o=geteOwner(owner)
    if o:
        VReturn=VReturn+'.'+o
    p=getPhasingcode(phasingcode)
    if p:
        VReturn=VReturn+'.'+p
    op=getOPVoltage(OPVoltage)
    if op:
        VReturn=VReturn+op
    s=getSubtype(fctype,subtype)
    if s:
        VReturn=VReturn+s

    if len(VReturn)>20:
        #print('{} is too long!'.format(VReturn))
        VReturn=VReturn[:20]
    return VReturn
def getSymbolID(fcname,vlist):
    if '.' in fcname:
        fcname=fcname.split('.')[-1]
    if fcname in ['eSwitchBank','eFuseBank']:
        if len(vlist)==8+2:
            return getFuseSwitchSymbolID(fcname,vlist[0],vlist[1],vlist[2],vlist[3],vlist[4],vlist[5],vlist[6],vlist[7])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif fcname =='eMiscellaneousNetworkFeature':
        if len(vlist)==4+2:
            return getNodeSymbolID(fcname,vlist[0],vlist[1],vlist[2],vlist[3])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif fcname =='eServiceLocation':
        if len(vlist)==2+2:
            return getServiceSymbolID(fcname,vlist[0],vlist[1])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif fcname =='eTransformerBank':
        if len(vlist)==5+2:
            return getTXSymbolID(vlist[0],vlist[1],vlist[2],vlist[3],vlist[4])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif  fcname in ['ePrimaryOHLineSection','ePrimaryUGLineSection']:
        if len(vlist)==5+2:
            return getPrimarySymbolID(fcname,vlist[0],vlist[1],vlist[2],vlist[3],vlist[4])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif  fcname in ['eSecondaryOHLineSection','eSecondaryUGLineSection']:
        if len(vlist)==1+2:
                    return getOPVoltage(vlist[0])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif fcname =='eRoadCentreLines':
        if len(vlist)==1+2:
                    return vlist[0]
    elif  fcname in ['eSurfaceStructure','eUndergroundStructure','Elster_Equip','eDynamicProtectiveDeviceBank']:
        if len(vlist)==1+2:
            return getSymbolIDSubtype(fcname,vlist[0])
        else:
            print('field list is wrong:{}'.format(vlist))
    elif  fcname in ['eLight','ePole']:
        if len(vlist)==1+2:
            return getSymbolIDStatus(vlist[0])
    elif fcname =='eSubstation':
        if len(vlist)==1+2:
                    return geteOwner(vlist[0])
        else:
            print('field list is wrong:{}'.format(vlist))
    return '!!!!Not Implement!!!!'

def processfc(gdb,fcname):

    fldlist=['SUBTYPECODE','OBJECTID','SYMBOLID']
    if fcname in ['eLight','ePole']:
        fldlist=['WORKFLOWSTATUS','OBJECTID','SYMBOLID']
    elif fcname =='eRoadCentreLines':
        fldlist=['PLAN_CLASS','OBJECTID','SYMBOLID']
    elif fcname =='eSubstation':
        fldlist=['OWNER','OBJECTID','SYMBOLID']
    elif  fcname in ['eSecondaryOHLineSection','eSecondaryUGLineSection']:
        fldlist=['OPERVOLT','OBJECTID','SYMBOLID']
    elif  fcname in ['eSwitchBank','eFuseBank']:
        fldlist=['FEEDERID','OWNER','OPERATINGVOLTAGE','PHASINGCODE','SUBTYPECODE','NORMALR','NORMALW','NORMALB','OBJECTID','SYMBOLID']
    elif  fcname in ['ePrimaryOHLineSection','ePrimaryUGLineSection']:
        fldlist=['FEEDERID','OWNER','PHASINGCODE','OPERVOLT','SUBTYPECODE','OBJECTID','SYMBOLID']
    elif  fcname =='eMiscellaneousNetworkFeature':
        fldlist=['SUBTYPECODE','PHASINGCODE','FEEDERID','OPERATINGVOLTAGE','OBJECTID','SYMBOLID']
    elif fcname =='eServiceLocation':
        fldlist=['SUBTYPECODE','CRITICALCUSTOMER','OBJECTID','SYMBOLID']
    elif fcname =='eTransformerBank':
        fldlist=['FEEDERID','OWNER','OPERATINGVOLTAGE','PHASINGCODE','STYLE','OBJECTID','SYMBOLID']
    #fc=r'{}\PRODETGIS.ARCFM.ElectricDataset\PRODETGIS.ARCFM.{}'.format(gdb,fcname)

    if joinCheck(gdb):
        fldlist=['PRODETGIS.ARCFM.'+fcname+'.'+ fld for fld in fldlist]
    expression = u'{} > 0'.format(arcpy.AddFieldDelimiters(gdb, fldlist[-2]))
    cursor=arcpy.da.SearchCursor(gdb, fldlist,where_clause=expression)
    #print('query1--'+expression)
    return Find4Update(cursor,fcname)

    #ucnt=0
def Find4Update(cursor,fcname):
    oidlist=[]
    for r in cursor:
        s=getSymbolID(fcname,r)
        oldSID=r[-1]
        uoid= r[-2]
        if s!=oldSID:
            #print(s,oldSID)
            oidlist.append([uoid,s,oldSID])

##    del r
    del cursor

    return oidlist
def updatelayer(currentLayerodf,fieldName='SYMBOLID'):
    returntext=''
    logger.info('..in updatelayer..')
    fclist=['eTransformerBank','eMiscellaneousNetworkFeature','ePrimaryOHLineSection','ePrimaryUGLineSection','eSwitchBank','eFuseBank']
    if isinstance(currentLayerodf, arcpy.mapping.Layer):
        #print(currentLayerodf.name)
        if not currentLayerodf.isGroupLayer:
            if currentLayerodf.supports("DATASOURCE"):
                lst=[]
                for fcname in fclist:
                    if fcname in currentLayerodf.dataSource:
                        logger.info('***process:{}-{}***'.format(currentLayerodf.name,fcname))
                        #pythonaddins.MessageBox(currentLayerodf.dataSource, 'INFO', 0)
                        lst=processfc(currentLayerodf,fcname)
                        logger.info('{} records in {} selected'.format(len(lst),currentLayerodf.name))
                        cnt=0
                        if len(lst)>0:
                            objfld='OBJECTID'
                            if joinCheck(currentLayerodf):
                                objfld='PRODETGIS.ARCFM.'+fcname+'.'+ objfld
                                fieldName='PRODETGIS.ARCFM.'+fcname+'.'+ fieldName
                            try:
                                for ud in lst:
                                    logger.info(ud)
                                    wc = u'{} = {}'.format(arcpy.AddFieldDelimiters(currentLayerodf, objfld),ud[0])
                                    logger.info(wc)
                                    #pythonaddins.MessageBox('processing where "{}"'.format(wc), 'INFO', 0)
                                    arcpy.SelectLayerByAttribute_management(currentLayerodf, "NEW_SELECTION", wc)
                                    #pythonaddins.MessageBox('updating field:{} with expression: "{}"'.format(fieldName, expression), 'INFO', 0)
                                    newvalue='"'+ ud[1]+'"'
                                    logger.info(fieldName+':'+newvalue)
                                    arcpy.CalculateField_management(currentLayerodf, fieldName, newvalue, "PYTHON_9.3")
                                    cnt+=1
                                    #break
                                returntext +='{} records in {} updated.'.format(cnt,fcname)

                            except Exception, e:
                                msg='Failed to update feature in layer {}: {} '.format(currentLayerodf.name, str(e))
                                logger.error(msg)
                                return msg
                        else:
                            returntext='The layer you select has no record to update!'
                            #rt=calc(currentLayerodf)
                        #pythonaddins.MessageBox('{} records updated in {}'.format(cnt,fcname), 'INFO', 0)
            else:
                returntext='The layer you select is not implemented to calculate!'
        else:
            returntext='The layer you select is not feature layer or table!'
    else:
        returntext='Select a layer or table'
    return returntext
def Selectlayer(lyr):
    returntext=''
    fclist=['eTransformerBank','eMiscellaneousNetworkFeature','ePrimaryOHLineSection','ePrimaryUGLineSection','eSwitchBank','eFuseBank']
    if isinstance(lyr, arcpy.mapping.Layer):
        #print(df.name)
        if not lyr.isGroupLayer:
            if lyr.supports("DATASOURCE"):
                lst=[]
                for fcname in fclist:
                    if fcname in lyr.dataSource:
                        #pythonaddins.MessageBox(lyr.dataSource, 'INFO', 0)
                        lst=processfc(lyr,fcname)
                        #pythonaddins.MessageBox('{} records in {} selected'.format(len(lst),lyr.name), 'INFO', 0)
                        if len(lst)>0:
                            oidlist=[str(l[0]) for l in lst]
                            #oidlist=oidlist[:10]
                            objfld='OBJECTID'
                            if joinCheck(lyr):
                                objfld='PRODETGIS.ARCFM.'+fcname+'.'+ objfld
                            query = u'{} in ({})'.format(arcpy.AddFieldDelimiters(lyr, objfld),','.join(oidlist))
                            returntext += 'query: {} \n'.format(query)
                            arcpy.SelectLayerByAttribute_management(lyr, "NEW_SELECTION", query)
                            result = arcpy.GetCount_management(lyr)
                            returntext +='{} has {} records selected.'.format(lyr, result[0])
                            #pythonaddins.MessageBox('selected is done.', 'INFO', 0)
                            df.zoomToSelectedFeatures()
                        else:
                            returntext='The layer you select has no record to update!'

    else:
        returntext='Select a layer or table'
    return returntext
class clsUpdate(object):
    """Implementation for SymbolIDUpdate.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        logger.info('....run in addin.....')
        mxd = arcpy.mapping.MapDocument('current')
        currentLayerodf = pythonaddins.GetSelectedTOCLayerOrDataFrame()
        r=pythonaddins.MessageBox('Please make sure your edit session is open, If not, Select cancel.', 'INFO', 1)
        if r=='Cancel':
            return
        logger.info(currentLayerodf.name)
        msg=updatelayer(currentLayerodf)
        pythonaddins.MessageBox(msg, 'INFO', 0)
        logger.info('....onclick processed.....')
class clsFind4Update(object):
    """Implementation for FindSym2Update_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        logger.info('....run in addin.....')
        r='OK' #pythonaddins.MessageBox('If you have an edit session open, this script will update SymbolID of those records need to be updated in selected layer. If there is no edit session open, those records need to be updated will be selected. Select cancel if your edit session is not in the right status.', 'INFO', 1)
        if r=='Cancel':
            return
        mxd = arcpy.mapping.MapDocument('current')
        df= arcpy.mapping.ListDataFrames(mxd, "Layers") [0]
        lyr = pythonaddins.GetSelectedTOCLayerOrDataFrame()
        msg=Selectlayer(lyr)
        pythonaddins.MessageBox(msg, 'INFO', 0)
        logger.info('....onclick processed.....')

logger=initLogger(r'c:\temp')
logger.info('****Started.***')
if __name__ == "__main__":
    logger=initLogger(r'c:\temp')
    logger.info('....run standalone.....')
    field_name='OBJECTID'
    mxd=arcpy.mapping.MapDocument(r'C:\Projects\ArcMapPythonAddins\test.mxd')
    df = arcpy.mapping.ListDataFrames(mxd, '')[0] # Chooses the first dataframe
    desc=None
    for lyr in arcpy.mapping.ListLayers(mxd, '', df): # Loop through layers
        print('-----------------------------------------------')
        if isinstance(lyr, arcpy.mapping.Layer):
            if not lyr.isGroupLayer:
                if lyr.supports("DATASOURCE"):
                    if 'eSwitchBank' in lyr.dataSource:
                        msg=Selectlayer(lyr)
                        print (msg)
                        msg=updatelayer(lyr)
                        print (msg)
                    if 'eTransformerBank' in lyr.dataSource:
                        msg=Selectlayer(lyr)
                        print (msg)
                        msg=updatelayer(lyr)
                        print (msg)

    logger.info('....run finished.....')